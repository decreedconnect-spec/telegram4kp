/**
 * 4kpnote Cloud Voice Bot - Production Ready
 * Cloudflare Worker - Telegram Voice Bot
 * Trigger: 4kpnote|voice|text
 * 
 * APIs:
 * - Telegram Bot API (webhook)
 * - Gemini AI (speech optimization)
 * - Resemble AI (text-to-speech)
 */

// ==================== CONFIGURATION ====================
const CONFIG = {
  TELEGRAM_API_BASE: 'https://api.telegram.org/bot',
  GEMINI_API_BASE: 'https://generativelanguage.googleapis.com/v1beta/models',
  GEMINI_MODEL: 'gemini-2.0-flash',
  RESEMBLE_API_URL: 'https://f.cluster.resemble.ai/synthesize',
  MAX_TEXT_LENGTH: 1500,
  WEBHOOK_SECRET_HEADER: 'X-Webhook-Secret',
};

// ==================== VOICE PRESETS ====================
const VOICE_PRESETS = {
  default: {
    id: 'default',
    name: 'Default',
    description: 'Balanced natural voice',
    resemble_voice_id: 'default',
    emoji: '🔊',
    style: 'natural, clear, conversational'
  },
  male: {
    id: 'male',
    name: 'Male',
    description: 'Warm male voice',
    resemble_voice_id: 'male',
    emoji: '👨',
    style: 'warm, confident, articulate male voice'
  },
  female: {
    id: 'female',
    name: 'Female',
    description: 'Clear female voice',
    resemble_voice_id: 'female',
    emoji: '👩',
    style: 'clear, warm, expressive female voice'
  },
  deep: {
    id: 'deep',
    name: 'Deep',
    description: 'Deep resonant voice',
    resemble_voice_id: 'deep',
    emoji: '🎙️',
    style: 'deep, resonant, authoritative voice'
  },
  calm: {
    id: 'calm',
    name: 'Calm',
    description: 'Soft calming voice',
    resemble_voice_id: 'calm',
    emoji: '😌',
    style: 'soft, calming, soothing meditation voice'
  },
  energetic: {
    id: 'energetic',
    name: 'Energetic',
    description: 'Upbeat energetic voice',
    resemble_voice_id: 'energetic',
    emoji: '⚡',
    style: 'energetic, enthusiastic, upbeat voice'
  },
  whisper: {
    id: 'whisper',
    name: 'Whisper',
    description: 'Soft whisper voice',
    resemble_voice_id: 'whisper',
    emoji: '🤫',
    style: 'soft whisper, intimate, quiet voice'
  },
  professional: {
    id: 'professional',
    name: 'Professional',
    description: 'Business professional voice',
    resemble_voice_id: 'professional',
    emoji: '💼',
    style: 'professional, polished, business presentation voice'
  }
};

// ==================== LOGGING SYSTEM ====================
class Logger {
  constructor(env) {
    this.env = env;
    this.logs = [];
  }

  info(message, data = {}) {
    const entry = { level: 'INFO', timestamp: new Date().toISOString(), message, data };
    this.logs.push(entry);
    console.log(`[INFO] ${message}`, JSON.stringify(data));
  }

  error(message, error, data = {}) {
    const entry = {
      level: 'ERROR',
      timestamp: new Date().toISOString(),
      message,
      error: error?.message || error,
      stack: error?.stack,
      data
    };
    this.logs.push(entry);
    console.error(`[ERROR] ${message}`, error?.message || error, JSON.stringify(data));
  }

  warn(message, data = {}) {
    const entry = { level: 'WARN', timestamp: new Date().toISOString(), message, data };
    this.logs.push(entry);
    console.warn(`[WARN] ${message}`, JSON.stringify(data));
  }

  async flush() {
    if (this.logs.length > 0 && this.env?.LOGS_KV) {
      try {
        const key = `logs_${Date.now()}`;
        await this.env.LOGS_KV.put(key, JSON.stringify(this.logs), {
          expirationTtl: 7 * 24 * 60 * 60 // 7 days
        });
      } catch (e) {
        console.error('Failed to flush logs to KV:', e);
      }
    }
  }
}

// ==================== TELEGRAM API CLIENT ====================
class TelegramClient {
  constructor(botToken, logger) {
    this.botToken = botToken;
    this.apiBase = `${CONFIG.TELEGRAM_API_BASE}${botToken}`;
    this.logger = logger;
  }

  async makeRequest(method, body = {}) {
    const url = `${this.apiBase}/${method}`;
    try {
      const response = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body)
      });

      const data = await response.json();

      if (!data.ok) {
        throw new Error(`Telegram API error: ${data.description}`);
      }

      return data.result;
    } catch (error) {
      this.logger.error(`Telegram API ${method} failed`, error);
      throw error;
    }
  }

  async sendMessage(chatId, text, options = {}) {
    return this.makeRequest('sendMessage', {
      chat_id: chatId,
      text,
      parse_mode: 'HTML',
      ...options
    });
  }

  async sendVoice(chatId, voiceUrl, options = {}) {
    return this.makeRequest('sendVoice', {
      chat_id: chatId,
      voice: voiceUrl,
      ...options
    });
  }

  async sendVoiceByFileId(chatId, fileId, options = {}) {
    return this.makeRequest('sendVoice', {
      chat_id: chatId,
      voice: fileId,
      ...options
    });
  }

  async sendVoiceUpload(chatId, audioBlob, options = {}) {
    const formData = new FormData();
    formData.append('chat_id', chatId);
    formData.append('voice', audioBlob, 'voice.ogg');
    if (options.caption) formData.append('caption', options.caption);

    const response = await fetch(`${this.apiBase}/sendVoice`, {
      method: 'POST',
      body: formData
    });

    const data = await response.json();
    if (!data.ok) {
      throw new Error(`Telegram sendVoice error: ${data.description}`);
    }
    return data.result;
  }

  async sendChatAction(chatId, action = 'record_voice') {
    return this.makeRequest('sendChatAction', {
      chat_id: chatId,
      action
    });
  }

  async setWebhook(url, secretToken) {
    return this.makeRequest('setWebhook', {
      url,
      secret_token: secretToken,
      allowed_updates: ['message', 'callback_query']
    });
  }

  async deleteWebhook() {
    return this.makeRequest('deleteWebhook');
  }

  async getWebhookInfo() {
    return this.makeRequest('getWebhookInfo');
  }

  async answerCallbackQuery(callbackQueryId, text = null) {
    const body = { callback_query_id: callbackQueryId };
    if (text) body.text = text;
    return this.makeRequest('answerCallbackQuery', body);
  }

  async editMessageText(chatId, messageId, text, options = {}) {
    return this.makeRequest('editMessageText', {
      chat_id: chatId,
      message_id: messageId,
      text,
      parse_mode: 'HTML',
      ...options
    });
  }
}

// ==================== AI SPEECH AGENT ====================
class SpeechAgent {
  constructor(apiKey, logger) {
    this.apiKey = apiKey;
    this.logger = logger;
  }

  /**
   * Process text through Gemini AI to create natural spoken format
   * Adds pauses, emotion tags, and optimizes for TTS
   */
  async process(text, voiceStyle = 'natural, clear, conversational') {
    this.logger.info('SpeechAgent: Processing text', { textLength: text.length });

    const prompt = this.buildPrompt(text, voiceStyle);

    try {
      const response = await fetch(
        `${CONFIG.GEMINI_API_BASE}/${CONFIG.GEMINI_MODEL}:generateContent?key=${this.apiKey}`,
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            contents: [{
              role: 'user',
              parts: [{ text: prompt }]
            }],
            generationConfig: {
              temperature: 0.7,
              maxOutputTokens: 2048,
              topP: 0.9
            }
          })
        }
      );

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`Gemini API error: ${response.status} - ${errorText}`);
      }

      const data = await response.json();

      if (!data.candidates?.[0]?.content?.parts?.[0]?.text) {
        throw new Error('Invalid response format from Gemini API');
      }

      const processedText = data.candidates[0].content.parts[0].text.trim();
      this.logger.info('SpeechAgent: Text processed successfully', {
        originalLength: text.length,
        processedLength: processedText.length
      });

      return processedText;
    } catch (error) {
      this.logger.error('SpeechAgent: Processing failed', error);
      // Fallback: return original text with basic formatting
      return this.fallbackProcess(text);
    }
  }

  buildPrompt(text, voiceStyle) {
    return `You are an expert speech writer and voice optimization specialist. Your task is to transform written text into natural, spoken language optimized for text-to-speech (TTS) systems.

Voice Style: ${voiceStyle}

RULES:
1. Rewrite the text to sound natural when spoken aloud
2. Add strategic pauses using "..." for breathing and emphasis
3. Add emotion tags at appropriate points: (calm), (whisper), (excited), (serious), (warm), (thoughtful)
4. Convert numbers to spoken form (e.g., "42" → "forty-two")
5. Expand abbreviations (e.g., "AI" → "artificial intelligence", "etc." → "et cetera")
6. Replace symbols with words (e.g., "$" → "dollars", "%" → "percent")
7. Add natural transitions between ideas
8. Remove markdown formatting, URLs (say "link" instead), and special characters
9. Keep the original meaning intact
10. Optimize sentence length for speech rhythm
11. Maximum ${CONFIG.MAX_TEXT_LENGTH} characters

PAUSE GUIDELINES:
- Use "..." for short pauses (breathing)
- Use "... ..." for longer pauses (emphasis)
- Add pauses after important statements
- Add pauses before emotional shifts

EMOTION TAG GUIDELINES:
- (calm) - for soothing, peaceful content
- (whisper) - for intimate, secretive moments
- (excited) - for enthusiastic, high-energy content
- (serious) - for important, grave content
- (warm) - for friendly, welcoming content
- (thoughtful) - for reflective, contemplative content

TEXT TO PROCESS:
"""${text}"""

Return ONLY the processed speech text. No explanations, no markdown, just the spoken text ready for TTS.`;
  }

  fallbackProcess(text) {
    this.logger.warn('SpeechAgent: Using fallback processing');
    return text
      .replace(/\[PAUSE\s*(\d*)\]/gi, (match, seconds) => {
        const count = parseInt(seconds) || 1;
        return '...'.repeat(Math.min(count, 3));
      })
      .replace(/[\*\#\_\`\~\|]/g, '')
      .replace(/https?:\/\/\S+/g, 'link')
      .replace(/\n+/g, ' ... ')
      .substring(0, CONFIG.MAX_TEXT_LENGTH);
  }
}

// ==================== VOICE GENERATOR (Resemble AI) ====================
class VoiceGenerator {
  constructor(apiKey, logger) {
    this.apiKey = apiKey;
    this.logger = logger;
  }

  /**
   * Generate voice audio from text using Resemble AI
   */
  async generate(text, voicePreset = VOICE_PRESETS.default) {
    this.logger.info('VoiceGenerator: Starting generation', {
      voiceId: voicePreset.id,
      textLength: text.length
    });

    try {
      const response = await fetch(CONFIG.RESEMBLE_API_URL, {
        method: 'POST',
        headers: {
          'Authorization': `Token ${this.apiKey}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          body: text,
          voice: voicePreset.resemble_voice_id
        })
      });

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`Resemble API error: ${response.status} - ${errorText}`);
      }

      const data = await response.json();

      // Resemble returns audio_url
      const audioUrl = data.audio_url || data.url || data.audio;

      if (!audioUrl) {
        throw new Error('No audio URL in Resemble response');
      }

      this.logger.info('VoiceGenerator: Generation successful', { audioUrl });

      return {
        audioUrl,
        duration: data.duration || null,
        voiceUsed: voicePreset.id
      };
    } catch (error) {
      this.logger.error('VoiceGenerator: Generation failed', error);
      throw error;
    }
  }

  /**
   * Download audio from URL and return as Blob
   */
  async downloadAudio(audioUrl) {
    this.logger.info('VoiceGenerator: Downloading audio', { audioUrl });

    try {
      const response = await fetch(audioUrl, {
        headers: {
          'Authorization': `Token ${this.apiKey}`
        }
      });

      if (!response.ok) {
        throw new Error(`Failed to download audio: ${response.status}`);
      }

      const blob = await response.blob();
      this.logger.info('VoiceGenerator: Audio downloaded', { size: blob.size });
      return blob;
    } catch (error) {
      this.logger.error('VoiceGenerator: Download failed', error);
      throw error;
    }
  }
}

// ==================== COMMAND PARSER ====================
class CommandParser {
  /**
   * Parse 4kpnote command
   * Formats:
   * - 4kpnote text here (uses default voice)
   * - 4kpnote|voice|text here (uses specified voice)
   * - 4kpnote | voice | text here (spaced variant)
   */
  static parse(text) {
    if (!text || typeof text !== 'string') return null;

    const trimmed = text.trim();

    // Check if starts with 4kpnote (case insensitive)
    if (!trimmed.toLowerCase().startsWith('4kpnote')) return null;

    // Remove the trigger word
    let content = trimmed.slice(7).trim();

    if (!content) return null;

    // Check for pipe format: voice|text or voice | text
    const pipeMatch = content.match(/^\|?\s*([^|]+)\|\s*(.+)$/s);

    if (pipeMatch) {
      const voiceKey = pipeMatch[1].trim().toLowerCase();
      const messageText = pipeMatch[2].trim();
      const voicePreset = VOICE_PRESETS[voiceKey] || VOICE_PRESETS.default;

      return {
        command: '4kpnote',
        voice: voicePreset,
        voiceKey,
        text: messageText,
        original: trimmed
      };
    }

    // No voice specified, use default
    return {
      command: '4kpnote',
      voice: VOICE_PRESETS.default,
      voiceKey: 'default',
      text: content,
      original: trimmed
    };
  }

  /**
   * Check if text is a bot command
   */
  static isCommand(text) {
    if (!text) return false;
    return text.startsWith('/');
  }
}

// ==================== VOICE MENU BUILDER ====================
class VoiceMenuBuilder {
  /**
   * Build inline keyboard for voice selection
   */
  static buildVoiceMenu() {
    const voices = Object.values(VOICE_PRESETS);
    const rows = [];

    // Create 2-button rows
    for (let i = 0; i < voices.length; i += 2) {
      const row = [];
      row.push({
        text: `${voices[i].emoji} ${voices[i].name}`,
        callback_data: `voice_${voices[i].id}`
      });
      if (voices[i + 1]) {
        row.push({
          text: `${voices[i + 1].emoji} ${voices[i + 1].name}`,
          callback_data: `voice_${voices[i + 1].id}`
        });
      }
      rows.push(row);
    }

    return {
      inline_keyboard: rows
    };
  }

  /**
   * Build voice menu message text
   */
  static buildVoiceMenuText() {
    let text = '🎙️ <b>4kpnote Voice Selection</b>\n\n';
    text += 'Choose a voice for your message:\n\n';

    Object.values(VOICE_PRESETS).forEach(voice => {
      text += `${voice.emoji} <b>${voice.name}</b> - ${voice.description}\n`;
    });

    text += '\n<b>Usage:</b>\n';
    text += '• <code>4kpnote your text here</code>\n';
    text += '• <code>4kpnote|male|your text here</code>\n';
    text += '• <code>4kpnote|female|your text here</code>\n\n';
    text += 'Or tap a voice above to set your default!';

    return text;
  }
}

// ==================== USER PREFERENCES (KV STORAGE) ====================
class UserPreferences {
  constructor(kv) {
    this.kv = kv;
  }

  async getDefaultVoice(userId) {
    if (!this.kv) return VOICE_PRESETS.default;
    try {
      const voiceKey = await this.kv.get(`user_${userId}_voice`);
      return VOICE_PRESETS[voiceKey] || VOICE_PRESETS.default;
    } catch {
      return VOICE_PRESETS.default;
    }
  }

  async setDefaultVoice(userId, voiceKey) {
    if (!this.kv) return false;
    try {
      await this.kv.put(`user_${userId}_voice`, voiceKey);
      return true;
    } catch {
      return false;
    }
  }

  async getUsageCount(userId) {
    if (!this.kv) return 0;
    try {
      const count = await this.kv.get(`user_${userId}_count`);
      return parseInt(count) || 0;
    } catch {
      return 0;
    }
  }

  async incrementUsage(userId) {
    if (!this.kv) return;
    try {
      const count = await this.getUsageCount(userId);
      await this.kv.put(`user_${userId}_count`, (count + 1).toString());
    } catch {
      // Non-critical
    }
  }

  async cacheVoice(textHash, audioUrl, voiceId) {
    if (!this.kv) return;
    try {
      const cacheKey = `voice_${voiceId}_${textHash}`;
      await this.kv.put(cacheKey, audioUrl, { expirationTtl: 24 * 60 * 60 }); // 24 hours
    } catch {
      // Non-critical
    }
  }

  async getCachedVoice(textHash, voiceId) {
    if (!this.kv) return null;
    try {
      const cacheKey = `voice_${voiceId}_${textHash}`;
      return await this.kv.get(cacheKey);
    } catch {
      return null;
    }
  }
}

// ==================== MAIN BOT HANDLER ====================
class VoiceBot {
  constructor(env) {
    this.env = env;
    this.logger = new Logger(env);
    this.telegram = new TelegramClient(env.BOT_TOKEN, this.logger);
    this.speechAgent = new SpeechAgent(env.GEMINI_API_KEY, this.logger);
    this.voiceGenerator = new VoiceGenerator(env.RESEMBLE_API_KEY, this.logger);
    this.preferences = new UserPreferences(env.BOT_KV);
  }

  /**
   * Main entry point - handle incoming request
   */
  async handleRequest(request) {
    const url = new URL(request.url);

    // Health check endpoint
    if (url.pathname === '/health' && request.method === 'GET') {
      return new Response(JSON.stringify({
        status: 'healthy',
        bot: '4kpnote Cloud Voice Bot',
        version: '1.0.0',
        timestamp: new Date().toISOString()
      }), {
        headers: { 'Content-Type': 'application/json' }
      });
    }

    // Webhook endpoint
    if (url.pathname === '/webhook' && request.method === 'POST') {
      // Verify webhook secret if configured
      if (this.env.WEBHOOK_SECRET) {
        const secret = request.headers.get(CONFIG.WEBHOOK_SECRET_HEADER);
        if (secret !== this.env.WEBHOOK_SECRET) {
          this.logger.warn('Invalid webhook secret');
          return new Response('Unauthorized', { status: 401 });
        }
      }

      try {
        const update = await request.json();
        await this.handleUpdate(update);
        return new Response('OK', { status: 200 });
      } catch (error) {
        this.logger.error('Webhook handling failed', error);
        return new Response('Internal Server Error', { status: 500 });
      }
    }

    // Setup webhook endpoint (for manual setup)
    if (url.pathname === '/setup' && request.method === 'GET') {
      return this.handleSetup(url);
    }

    return new Response('Not Found', { status: 404 });
  }

  /**
   * Setup webhook with Telegram
   */
  async handleSetup(url) {
    try {
      const webhookUrl = `${url.origin}/webhook`;
      await this.telegram.setWebhook(webhookUrl, this.env.WEBHOOK_SECRET);

      const info = await this.telegram.getWebhookInfo();

      return new Response(JSON.stringify({
        status: 'Webhook configured',
        webhook_url: webhookUrl,
        webhook_info: info
      }, null, 2), {
        headers: { 'Content-Type': 'application/json' }
      });
    } catch (error) {
      this.logger.error('Webhook setup failed', error);
      return new Response(JSON.stringify({ error: error.message }), {
        status: 500,
        headers: { 'Content-Type': 'application/json' }
      });
    }
  }

  /**
   * Handle Telegram update
   */
  async handleUpdate(update) {
    this.logger.info('Received update', { updateId: update.update_id });

    // Handle callback queries (voice selection from menu)
    if (update.callback_query) {
      await this.handleCallbackQuery(update.callback_query);
      return;
    }

    // Handle messages
    if (update.message) {
      await this.handleMessage(update.message);
      return;
    }
  }

  /**
   * Handle callback queries from inline keyboards
   */
  async handleCallbackQuery(callbackQuery) {
    const { id, data, message } = callbackQuery;
    const chatId = message?.chat?.id;

    // Answer the callback to remove loading state
    await this.telegram.answerCallbackQuery(id);

    if (data.startsWith('voice_')) {
      const voiceKey = data.replace('voice_', '');
      const userId = callbackQuery.from.id;

      if (VOICE_PRESETS[voiceKey]) {
        await this.preferences.setDefaultVoice(userId, voiceKey);

        const voice = VOICE_PRESETS[voiceKey];
        await this.telegram.sendMessage(
          chatId,
          `✅ Default voice set to: ${voice.emoji} <b>${voice.name}</b>\n\n` +
          `Now you can simply send:\n` +
          `<code>4kpnote your text here</code>\n\n` +
          `Or override with:\n` +
          `<code>4kpnote|${voiceKey}|your text here</code>`
        );
      }
    }
  }

  /**
   * Handle incoming messages
   */
  async handleMessage(message) {
    const chatId = message.chat.id;
    const userId = message.from?.id;
    const text = message.text || message.caption || '';

    // Ignore empty messages
    if (!text) return;

    // Handle /start command
    if (text === '/start') {
      await this.handleStart(chatId);
      return;
    }

    // Handle /voices command
    if (text === '/voices') {
      await this.handleVoicesCommand(chatId);
      return;
    }

    // Handle /help command
    if (text === '/help') {
      await this.handleHelp(chatId);
      return;
    }

    // Handle 4kpnote trigger
    const parsed = CommandParser.parse(text);
    if (parsed) {
      await this.handleVoiceRequest(chatId, userId, parsed);
      return;
    }

    // If not a recognized command, show hint
    if (CommandParser.isCommand(text)) {
      await this.telegram.sendMessage(
        chatId,
        '❓ Unknown command. Send /help for usage instructions.'
      );
    }
  }

  /**
   * Handle /start command
   */
  async handleStart(chatId) {
    const welcomeText =
      '🎙️ <b>Welcome to 4kpnote Cloud Voice Bot!</b>\n\n' +
      'I transform your text into natural-sounding voice messages using AI.\n\n' +
      '<b>Quick Start:</b>\n' +
      '• <code>4kpnote Hello, this is a test message</code>\n' +
      '• <code>4kpnote|male|Hello in male voice</code>\n' +
      '• <code>4kpnote|female|Hello in female voice</code>\n\n' +
      '<b>Available Commands:</b>\n' +
      '• /voices - Choose your default voice\n' +
      '• /help - Show detailed help\n\n' +
      '<b>Voice Options:</b> default, male, female, deep, calm, energetic, whisper, professional';

    await this.telegram.sendMessage(chatId, welcomeText);
  }

  /**
   * Handle /voices command - show voice selection menu
   */
  async handleVoicesCommand(chatId) {
    const text = VoiceMenuBuilder.buildVoiceMenuText();
    const replyMarkup = VoiceMenuBuilder.buildVoiceMenu();

    await this.telegram.sendMessage(chatId, text, {
      reply_markup: replyMarkup
    });
  }

  /**
   * Handle /help command
   */
  async handleHelp(chatId) {
    const helpText =
      '📖 <b>4kpnote Voice Bot - Help</b>\n\n' +
      '<b>Basic Usage:</b>\n' +
      '<code>4kpnote Your text here</code>\n\n' +
      '<b>With Voice Selection:</b>\n' +
      '<code>4kpnote|voice|Your text here</code>\n\n' +
      '<b>Available Voices:</b>\n' +
      '🔊 Default - Balanced natural voice\n' +
      '👨 Male - Warm male voice\n' +
      '👩 Female - Clear female voice\n' +
      '🎙️ Deep - Deep resonant voice\n' +
      '😌 Calm - Soft calming voice\n' +
      '⚡ Energetic - Upbeat energetic voice\n' +
      '🤫 Whisper - Soft whisper voice\n' +
      '💼 Professional - Business voice\n\n' +
      '<b>Features:</b>\n' +
      '• AI-powered speech optimization\n' +
      '• Natural pauses and emotion tags\n' +
      '• Up to 1500 characters\n' +
      '• Voice caching for speed\n\n' +
      '<b>Examples:</b>\n' +
      '<code>4kpnote Welcome to the meeting everyone</code>\n' +
      '<code>4kpnote|deep|In a world where technology...</code>\n' +
      '<code>4kpnote|calm|Take a deep breath and relax</code>\n\n' +
      'Send /voices to open the voice selection menu!';

    await this.telegram.sendMessage(chatId, helpText);
  }

  /**
   * Handle 4kpnote voice request
   */
  async handleVoiceRequest(chatId, userId, parsed) {
    const startTime = Date.now();

    try {
      // Show typing action
      await this.telegram.sendChatAction(chatId, 'record_voice');

      // Check text length
      if (parsed.text.length > CONFIG.MAX_TEXT_LENGTH) {
        await this.telegram.sendMessage(
          chatId,
          `⚠️ Text too long (${parsed.text.length} chars). Maximum is ${CONFIG.MAX_TEXT_LENGTH} characters.`
        );
        return;
      }

      // Check if text is too short
      if (parsed.text.length < 2) {
        await this.telegram.sendMessage(
          chatId,
          '⚠️ Text too short. Please provide at least 2 characters.'
        );
        return;
      }

      // Get user's default voice if no voice specified in command
      let voicePreset = parsed.voice;
      if (parsed.voiceKey === 'default' && userId) {
        const userVoice = await this.preferences.getDefaultVoice(userId);
        if (userVoice.id !== 'default') {
          voicePreset = userVoice;
        }
      }

      // Check cache first
      const textHash = await this.hashText(parsed.text);
      const cachedUrl = await this.preferences.getCachedVoice(textHash, voicePreset.id);

      if (cachedUrl) {
        this.logger.info('Using cached voice', { voiceId: voicePreset.id });
        await this.telegram.sendVoice(chatId, cachedUrl, {
          caption: `🎙️ ${voicePreset.emoji} ${voicePreset.name} (cached)`
        });
        return;
      }

      // Step 1: Process text through AI speech agent
      await this.telegram.sendChatAction(chatId, 'record_voice');
      const processedText = await this.speechAgent.process(parsed.text, voicePreset.style);

      // Step 2: Generate voice
      await this.telegram.sendChatAction(chatId, 'record_voice');
      const voiceResult = await this.voiceGenerator.generate(processedText, voicePreset);

      // Step 3: Download audio from Resemble and upload to Telegram
      // (Direct URL may not be accessible by Telegram servers)
      const audioBlob = await this.voiceGenerator.downloadAudio(voiceResult.audioUrl);
      const telegramResponse = await this.telegram.sendVoiceUpload(chatId, audioBlob, {
        caption: `🎙️ ${voicePreset.emoji} ${voicePreset.name} voice`
      });

      // Cache the voice file_id for future use (Telegram caches files by file_id)
      const fileId = telegramResponse?.voice?.file_id;
      if (fileId) {
        await this.preferences.cacheVoice(textHash, fileId, voicePreset.id);
      }

      // Increment usage count
      await this.preferences.incrementUsage(userId);

      const duration = Date.now() - startTime;
      this.logger.info('Voice request completed', {
        duration: `${duration}ms`,
        voiceId: voicePreset.id,
        textLength: parsed.text.length
      });

    } catch (error) {
      this.logger.error('Voice request failed', error, { chatId, text: parsed.text });

      // Send user-friendly error message
      let errorMessage = '❌ <b>Sorry, something went wrong!</b>\n\n';

      if (error.message?.includes('Gemini')) {
        errorMessage += 'The AI speech agent encountered an error. Please try again.';
      } else if (error.message?.includes('Resemble')) {
        errorMessage += 'The voice generation service is temporarily unavailable. Please try again in a moment.';
      } else if (error.message?.includes('Telegram')) {
        errorMessage += 'There was an issue sending the voice message. Please try again.';
      } else {
        errorMessage += 'An unexpected error occurred. Please try again later.';
      }

      await this.telegram.sendMessage(chatId, errorMessage);
    } finally {
      await this.logger.flush();
    }
  }

  /**
   * Simple hash function for text caching
   */
  async hashText(text) {
    const encoder = new TextEncoder();
    const data = encoder.encode(text.toLowerCase().trim());
    const hashBuffer = await crypto.subtle.digest('SHA-256', data);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map(b => b.toString(16).padStart(2, '0')).join('').substring(0, 16);
  }
}

// ==================== CLOUDFLARE WORKER ENTRY POINT ====================
export default {
  async fetch(request, env, executionCtx) {
    const bot = new VoiceBot(env);
    return bot.handleRequest(request);
  }
};